ALVARADO
Alvarado is an open-source variable typeface based on vernacular signage found on the namesake street, specifically on the stretch through the Westlake and Pico-Union neighborhoods of Los Angeles which are among the highest population density in the USA: http://primary-foundry.com/typefaces/alvarado/


LICENSE
This Font Software is licensed under the SIL Open Font License, Version 1.1. This license is copied above, and is also available with a FAQ at: http://scripts.sil.org/OFL


AUTHORS
Alvarado has been designed by Hector Torres (astudionameddesire.com) and published by Primary Foundry (primary-foundry.com)


DESIGN
Alvarado was created by Hector Torres using Glyphs and the Dinamo Font Gauntlet (fontgauntlet.com)


***
